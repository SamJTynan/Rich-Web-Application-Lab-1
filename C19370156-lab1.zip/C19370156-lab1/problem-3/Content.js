document.body.innerHTML += '<div style="position:absolute;text-align:center;top:0px;width:100%;height:10%;z-index:100;background:#929292;marginBottom:70px;"><p></p></div>';
document.body.innerHTML += '<br> <br> <br> <br>';
const imgs = document.getElementsByTagName("img");
for(let i = 0; i < imgs.length; i++) {
    
    imgs[i].src = "http://clipart-library.com/images/gie5B478T.png";
}

const p = document.getElementsByTagName("p");
for (let i = 0; i < p.length; i++){
    p[i].innerText = "This website is broken";
	p[i].style.fontFamily = "Comic Sans MS";
}

var links = document.getElementsByTagName("a");
for (var i = 0; i < links.length ; i++) {
	links[i].innerText = "This link is broken.";	
    links[i].href = "BLANK";
	links[i].style.fontFamily = "Comic Sans MS";
}

const range = ["h1", "h2", "h3","h4","h5","h6","h7","h8"];
for (let i = 0; i < range.length; i++)
{
	const headers = document.getElementsByTagName(range[i]);
	for (let j = 0; j < headers.length; j++){
		headers[j].innerText = "Error";
		headers[j].style.fontFamily = "Comic Sans MS";
	}
}